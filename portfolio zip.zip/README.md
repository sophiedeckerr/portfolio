# portfolio
class project. Includes resumé, cover letter, and career goals 
